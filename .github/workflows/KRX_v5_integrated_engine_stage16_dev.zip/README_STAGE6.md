# Stage 6 — 실제 DART 10개 기업 시험 결과 연결

- `v5/v5_pilot_bridge.py`: GitHub Actions에서 생성된 `sample.json`의 6개 스냅샷 계정과 기존 v5 이력을 읽기 전용으로 연결.
- `pilot_diagnostics/`: 실제 업로드 ZIP을 이용해 생성한 10개 기업 진단 결과.
- 2026년 반기 매출과 지배주주 순이익은 **TTM이 아님**. 이전 FY/YTD 원본 3개 기간을 연결하기 전에는 ROE·ROA·성장률·PER·PBR을 확정하지 않음.
- `source_reconciled=False`, `investment_grade=None` 유지. 기존 v4/골든크로스 파일 변경 없음.
- 다음 단계: `v5_dart_live_collector.py`의 3기간 원본을 GitHub Actions에서 실행하여 TTM 및 12개월 전 지배주주 자본 검증.
