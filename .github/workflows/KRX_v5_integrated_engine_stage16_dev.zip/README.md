# v5 통합 진단 엔진 — 1차 개발 패키지

이 패키지는 기존 GitHub v4·골든크로스·v5 수집 파일을 수정하지 않습니다. **아직 운영 배포용이 아닙니다.**

- `v5/v5_integrated_engine.py`: 기존 이력 JSON + 선택적 ROE 파일럿 JSON + 선택적 시가총액 JSON을 읽어 단일 진단표 작성.
- `tests/test_integrated_engine.py`: 계산 기준 불일치, 음수 순이익, 누락, 미검증 등급 차단 회귀 시험.
- 미구현/입력 미확보: ROA 자산, 성장성 비교 재무, 재무건전성 부채, 공시 원본 정정 검증, 검증된 시가총액. 값을 임의로 채우지 않고 null 유지.

로컬 검증: `python -m unittest discover -s tests -v`

예시: `python v5/v5_integrated_engine.py --history v5_history/history_metrics.json --pilot pilot_details.json --output v5_integrated_output`

**주의:** 파일럿의 `ARITHMETIC_READY_SOURCE_REVIEW_REQUIRED`는 원본 검증 완료가 아닙니다. `investment_grade`는 항상 null입니다. 이 단계에서 투자 추천으로 사용하지 않습니다.

다음 통합 배치에서 필요한 입력: 기존 snapshot 원본 계정 항목 스키마, 자산/부채/매출 2개 이상 비교기간, 가격 기준일 및 시가총액, 정정공시 검증 결과. 모든 입력이 확보된 뒤 평가 점수를 연결합니다.

## 2차 통합 개발 (2026-11-04)
- `v5/v5_financial_extension.py`: 명시적으로 제공된 동일 기간 재무 입력을 이용해 ROE, ROA(지배주주 순이익 기준 임시 진단), 부채비율, 영업이익률, 매출 성장률, CFO/순이익, PER/PBR을 계산한다.
- `tests/test_financial_extension.py`: 5개 추가 회귀 테스트. 전체 9개 테스트 통과.
- 입력 JSON은 종목코드→{assets_current, liabilities_current, equity_current, revenue_ttm, revenue_prior_ttm, operating_income_ttm, owner_net_income_ttm, cfo_ttm, owner_equity_current, owner_equity_12m_prior, period_end, statement_type, source_reconciled, sector} 구조. 금액 단위는 모두 KRW. 시장 JSON은 종목코드→{market_cap_krw, asof}.
- **미연결:** 현재 GitHub 이력 JSON에는 위 모든 필드가 존재하지 않는다. OpenDART 원본을 이용한 필드 추출·비교기간 재조정·가격 데이터 확보는 다음 통합 개발 배치에 남겨둔다. `source_reconciled=True`는 실제 공시 검증 후에만 허용한다.
- 이 패키지는 운영 배포용이 아니며 실제 종목 등급은 발행하지 않는다. 기존 v4·골든크로스·자동 수집에는 변경 사항이 없다.
