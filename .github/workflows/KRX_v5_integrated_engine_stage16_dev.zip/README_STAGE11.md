# Stage 11: read-only CFO + financial-health join

Adds `v5/v5_stage11_financial_join.py`. Pilot 10-company sample is joined to a fixture constructed from CFO figures read from GitHub `v5-state/v5_history/history_metrics.json` on 2026-11-04. This fixture is not a live GitHub connector; rerun with full actual history JSON for complete validation.

Run: `python v5/v5_stage11_financial_join.py --pilot five_period_diagnostics.json --history history_10_fixture.json --output stage11_diagnostics`

Checks: period, statement type, 2026 H1 report identity, balance-sheet identity, debt/equity, provisional ROA and CFO/owner-income. Does not independently reconcile source filings. No production workflows or investment grades changed.
