# KRX v5 통합 엔진 3차 — 실제 이력 데이터 연결

1·2차 파일을 모두 포함한 통합 개발 패키지. `v5/v5_stage3_adapter.py`는 실제 GitHub `v5-state` 브랜치의 `v5_history/history_metrics.json` 형식에 연결하는 읽기 전용 어댑터다.

## 실행 (개발 환경)

```bash
python -m unittest discover -s tests -v
python v5/v5_stage3_adapter.py --history v5_history/history_metrics.json --output v5_stage3_output
```

`--history`에는 GitHub `v5-state`의 원본 JSON을 지정한다. 외부 API 키는 필요하지 않다. 이 도구는 v4, 골든크로스, v5 이력 원본, 평가 등급을 수정하지 않는다.

## 검증 범위와 미완료

- 실제 데이터 **스키마** 확인: `status`, `ttm_net_income_krw`, `roe_ttm_pct_diagnostic`, `cfo_ttm_krw`, `identity`, `formula`, `ISU_NM`, `period`.
- 기존 ROE는 연결 전체 기준이므로 진단용으로만 표시한다. 지배주주 ROE로 변환하거나 대체하지 않는다.
- 원본에는 자산/매출/지배주주 순이익/지배주주 자본/가격 기준일이 없어 ROA, 성장성, PER/PBR을 실제 계산할 수 없다. 2차 계산 함수는 입력이 준비되면 별도 사용한다.
- GitHub 최신 데이터 1,215개 기업 전체의 실행 검증은 아직 수행하지 않았다. 원본 파일을 확보해 실제 배치 실행 후 보완한다.
- 테스트는 고정 예제/입력형식 검증이지 OpenDART 원천 공시 검증이 아니다.

**배포 방침:** 아직 GitHub 운영 브랜치에 업로드하지 않는다. 최종 통합 배포 때 별도 수동 워크플로로 연결한다.

## 4차 누적 개발: OpenDART 원본 계정 연결 (독립 모듈)
- `v5/v5_dart_source_adapter.py`: `fnlttSinglAcntAll.json`의 원본 `list`를 기간별로 제공받아 자산, 부채, 자기자본, 지배주주자본, TTM 매출, 영업이익, 지배주주 순이익을 추출한다.
- 표준 계정 ID만 허용하며 동일 항목의 상충값은 null 처리한다. 손익계산서는 `thstrm_add_amount`(누적), 재무상태표는 `thstrm_amount`(시점)를 사용한다.
- `revenue_prior_ttm`은 전전기 사업보고서 등 추가 자료가 필요하므로 임의로 계산하지 않는다.
- 본 단계는 실제 DART 응답 원문과 연동된 수집기가 아니라 **수집된 원본 행의 변환기**다. 원본 수집, 공시 정정 검증, 전체 기업 실데이터 테스트는 미완료.
- 테스트 20개 통과. 운영 코드 및 등급 변경 없음.
