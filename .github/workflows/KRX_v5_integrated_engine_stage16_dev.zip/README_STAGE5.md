# v5 통합 5차: 실제 OpenDART 수집기 (배포 전 개발본)

- 기존 1~4차 코드를 포함한다. **운영 브랜치·v4·골든크로스·등급 변경 없음.**
- `v5/v5_dart_live_collector.py`는 `DART_API_KEY`를 환경변수로 받아 `corpCode.xml`을 조회하고, 기존 v5-state 이력의 기업 코드·연도·보고서 구분으로 각 기업당 세 기간의 원본 계정행을 조회한다.
- 10개 기업 한정 기본 실행, `--limit` 1~50. 조회 실패 기업은 기록하고 다른 기업으로 계속한다.
- 출력은 `dart_provisional.json`, `summary.json`이며 **전부 미검증/무등급**이다. 원본 재무제표의 비교 공시·정정 공시를 검증하지 않았고, ROA/PER/PBR 확정 점수를 내지 않는다.
- GitHub workflow는 별도 **수동 실행**용이며 실제 API 키와 GitHub 업로드가 있어야 실데이터 테스트가 가능하다. GitHub에 아직 업로드하지 않았다.
- 실행: `python -m unittest discover -s tests -v`; `python v5/v5_dart_live_collector.py --history v5_history/history_metrics.json --limit 10`
- **주의:** 현재 어댑터는 일부 회사의 `thstrm_add_amount` 부재나 사업보고서·분기 비교 공시를 보완하지 못하므로 결과를 검증 전 투자 판단에 사용하지 않는다.
