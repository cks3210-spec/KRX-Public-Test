# Stage 15 — Live history audit and change detection

Read-only, compares latest `v5-state/v5_history/history_metrics.json` to the **352-company Stage 14 baseline**. Generates summary.json, diagnostics.json, changes.json and triage.json. No investment grades. `COMPLETE` is a collector state, **not** OpenDART source verification. The baseline is intentionally fixed; new/removed codes are relative to that baseline.

Run: `python v5/v5_stage15_live_audit.py --input history_metrics.json --baseline stage14_baseline_diagnostics.json --output stage15_report`

Workflow `.github/workflows/v5-live-history-audit.yml` is standalone and downloads v5-state at execution time; no repository writes.
