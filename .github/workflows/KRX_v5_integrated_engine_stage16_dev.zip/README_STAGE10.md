# Stage 10: read-only five-period diagnostic reconciliation

- Rebuild missing-field list from actual values; remove stale missing flags.
- Classify profit/loss transitions without misleading negative-denominator growth percentages.
- Optionally join CFO from historical records only on matching period, statement type and COMPLETE status. A matched period is NOT independent filing reconciliation; CFO-to-owner-profit is diagnostic only.
- All outputs remain provisional, with source_reconciled=false and investment_grade=null.

Run: `python v5/v5_stage10_reconcile.py --pilot five_period_diagnostics.json --history history_metrics.json --output stage10_diagnostics`.
If history file is unavailable, omit `--history`; CFO remains null. No production workflows changed.
