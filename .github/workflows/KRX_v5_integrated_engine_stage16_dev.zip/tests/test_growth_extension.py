import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_growth_extension import prior_ttm,extend

def row(account,value):return {'sj_div':'IS','account_id':account,'account_detail':'-','thstrm_amount':str(value),'thstrm_add_amount':str(value)}
class GrowthTests(unittest.TestCase):
 def test_prior_ttm_formula(self):
  a='ifrs-full_Revenue'
  self.assertEqual(prior_ttm('revenue',[row(a,40)],[row(a,100)],[row(a,30)]),110)
 def test_missing_period_no_fake_growth(self):
  result=extend('000020',{'financial':{'revenue_ttm':120,'revenue_prior_ttm':999}})
  self.assertIsNone(result['financial']['revenue_prior_ttm'])
  self.assertIsNone(result['diagnostic']['revenue_growth_ttm_pct_provisional'])
  self.assertIsNone(result['investment_grade'])
 def test_growth_and_balance(self):
  ids={'revenue':'ifrs-full_Revenue','operating_income':'dart_OperatingIncomeLoss','owner_net_income':'ifrs-full_ProfitLossAttributableToOwnersOfParent'}
  periods={'prior_ytd_rows':[],'fy_two_years_ago_rows':[],'two_years_ago_ytd_rows':[]}
  for k,account in ids.items():
   periods['prior_ytd_rows'].append(row(account,40))
   periods['fy_two_years_ago_rows'].append(row(account,100))
   periods['two_years_ago_ytd_rows'].append(row(account,30))
  f={'assets_current':300,'liabilities_current':100,'equity_current':200,'owner_equity_current':190,'owner_equity_12m_prior':180,'revenue_ttm':121,'operating_income_ttm':121,'owner_net_income_ttm':121,'period_end':'2026-06-30','statement_type':'CFS'}
  result=extend('000020',{'financial':f,'additional_periods':periods})
  self.assertEqual(result['diagnostic']['revenue_growth_ttm_pct_provisional'],10)
  self.assertEqual(result['diagnostic']['operating_income_growth_ttm_pct_provisional'],10)
  self.assertIsNone(result['investment_grade'])
if __name__=='__main__':unittest.main()
