import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_integrated_engine import calculate,ratio
class EngineTests(unittest.TestCase):
 def test_denominator_guard(self):
  self.assertIsNone(ratio(10,0));self.assertIsNone(ratio(10,-1));self.assertIsNone(ratio(None,3))
 def test_no_grade(self):
  h={'status':'COMPLETE','ISU_NM':'sample','roe_ttm_pct_diagnostic':4.913,'ttm_net_income_krw':642167000000,'cfo_ttm_krw':821657000000}
  p={'status':'ARITHMETIC_READY_SOURCE_REVIEW_REQUIRED','roe_owner_ttm_pct':17.7487,'owner_ttm_net_income':367820000000,'owner_equity_current':2609734000000}
  r=calculate('000150',h,p)
  self.assertEqual(r['investment_grade'],None)
  self.assertIn('ROE_BASIS_DIFFERENCE_2PP',r['flags'])
  self.assertIsNone(r['per_provisional'])
 def test_negative_profit(self):
  r=calculate('000140',{'status':'COMPLETE','roe_ttm_pct_diagnostic':1.726}, {'status':'ARITHMETIC_READY_SOURCE_REVIEW_REQUIRED','roe_owner_ttm_pct':-.4386,'owner_ttm_net_income':-2541938430},{'market_cap_krw':10000000000,'asof':'2026-11-04'})
  self.assertIsNone(r['per_provisional']);self.assertIsNone(r['investment_grade'])
 def test_no_unverified_pilot(self):
  r=calculate('1',{}, {'status':'ERROR','roe_owner_ttm_pct':12})
  self.assertIsNone(r['owner_roe_pct_provisional'])
if __name__=='__main__':unittest.main()
