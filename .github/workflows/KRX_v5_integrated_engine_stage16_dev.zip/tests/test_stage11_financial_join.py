import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_stage11_financial_join import join
class TestStage11(unittest.TestCase):
 def sample(self):
  return {'000020':{'period':'2026_H1','financial':{'statement_type':'CFS','owner_net_income_ttm':10,'assets_current':100,'liabilities_current':40,'equity_current':60,'revenue_prior_ttm':20},'diagnostic':{}}}
 def hist(self):
  return {'000020':{'period':'2026_H1','identity':['2026','11012','CFS'],'status':'COMPLETE','cfo_ttm_krw':30}}
 def test_matched(self):
  r=join(self.sample(),self.hist())['000020'];self.assertEqual(r['financial']['cfo_ttm'],30);self.assertEqual(r['financial']['balance_sheet_difference_krw'],0);self.assertIsNone(r['investment_grade'])
 def test_wrong_report(self):
  h=self.hist();h['000020']['identity'][1]='11014';r=join(self.sample(),h)['000020'];self.assertIsNone(r['financial']['cfo_ttm']);self.assertIn('CFO_REPORT_IDENTITY_MISMATCH',r['diagnostic']['flags'])
 def test_unbalanced(self):
  p=self.sample();p['000020']['financial']['assets_current']=101;r=join(p,self.hist())['000020'];self.assertIn('BALANCE_SHEET_NOT_BALANCED',r['diagnostic']['flags'])
