import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_stage16_source_readiness import review
class TestStage16(unittest.TestCase):
 def test_ofs_needs_proof(self):
  s,r=review({'000001':{'status':'COMPLETE','identity':['2026','11012','OFS'],'period':'2026_H1','cfo_ttm_krw':0,'ttm_net_income_krw':0,'roe_ttm_pct_diagnostic':0,'equity_end_krw':1}})
  self.assertEqual(r[0]['category'],'OFS_PROOF');self.assertFalse(r[0]['source_reconciled'])
 def test_partial_priority(self):
  s,r=review({'000001':{'status':'PARTIAL','identity':['2026','11012','OFS']}})
  self.assertEqual(r[0]['category'],'RECOLLECT')
 def test_no_grade(self):
  s,r=review({'000001':{'status':'PARTIAL'}})
  self.assertEqual(s['investment_grades_created'],0);self.assertIsNone(r[0]['grade'])
 def test_zero_not_missing(self):
  s,r=review({'000001':{'status':'COMPLETE','identity':['2026','11012','CFS'],'period':'2026_H1','cfo_ttm_krw':0,'ttm_net_income_krw':0,'roe_ttm_pct_diagnostic':0,'equity_end_krw':1}})
  self.assertEqual(r,[])
if __name__=='__main__':unittest.main()
