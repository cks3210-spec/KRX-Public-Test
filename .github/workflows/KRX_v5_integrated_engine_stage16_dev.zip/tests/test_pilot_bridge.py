import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_pilot_bridge import bridge
class BridgeTests(unittest.TestCase):
 def test_no_annualize_h1(self):
  p={'000001':{'name':'test','status':'PROVISIONAL','period':'2026_H1','metrics':{'assets':100,'liabilities':40,'equity':60,'owner_equity':61,'revenue':50,'owner_profit':8}}}
  d=bridge(p)['000001']
  self.assertIsNone(d['roe_owner_ttm_pct_provisional'])
  self.assertIsNone(d['revenue_growth_ttm_pct_provisional'])
  self.assertIsNone(d['investment_grade'])
  self.assertEqual(d['owner_equity_minus_total_equity_krw'],1)
  self.assertIn('BALANCE_IDENTITY_EXACT_MATCH',d['flags'])
 def test_bad_balance(self):
  p={'1':{'status':'PROVISIONAL','metrics':{'assets':100,'liabilities':40,'equity':50}}}
  self.assertIn('BALANCE_SHEET_IDENTITY_MISMATCH',bridge(p)['1']['flags'])
if __name__=='__main__':unittest.main()
