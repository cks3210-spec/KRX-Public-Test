import io, unittest, zipfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_dart_live_collector import corp_mapping, collect
class TestLiveCollector(unittest.TestCase):
 def test_corp_mapping(self):
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:z.writestr('CORPCODE.xml','<result><list><stock_code>000020</stock_code><corp_code>00123456</corp_code></list></result>')
  self.assertEqual(corp_mapping(b.getvalue())['000020'],'00123456')
 def test_collection_no_grade(self):
  hist={'000020':{'status':'COMPLETE','identity':['2026','11012','CFS'],'ISU_NM':'테스트','period':'2026_H1'}}
  calls=[]
  def fake(endpoint,params):
   calls.append(params['reprt_code']);return []
  out=collect(hist,{'000020':'00123456'},limit=1,sleep=0,fetch=fake)
  self.assertEqual(calls,['11012','11011','11012'])
  self.assertIsNone(out['000020']['financial']['investment_grade'])
 def test_fetch_error_isolated(self):
  hist={'000020':{'status':'PARTIAL','identity':['2026','11012','CFS']}}
  def fail(*args):raise RuntimeError('API failure')
  self.assertEqual(collect(hist,{'000020':'00123456'},1,0,fail)['000020']['status'],'FETCH_ERROR')
if __name__=='__main__':unittest.main()
