import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_stage10_reconcile import reconcile,transition
class TestStage10(unittest.TestCase):
 def test_turns(self):
  self.assertEqual(transition(2,-3),'TURNED_PROFIT')
  self.assertEqual(transition(-2,3),'TURNED_LOSS')
  self.assertEqual(transition(-2,-3),'LOSS_CONTINUES')
 def test_missing_rebuilt(self):
  x={'000001':{'period':'2026_H1','financial':{'revenue_prior_ttm':10,'missing':['revenue_prior_ttm'],'statement_type':'CFS'},'diagnostic':{'flags':['MISSING_REVENUE_PRIOR_TTM']}}}
  r=reconcile(x)['000001'];self.assertNotIn('revenue_prior_ttm',r['financial']['missing']);self.assertIsNone(r['investment_grade'])
 def test_cfo_guard(self):
  x={'000001':{'period':'2026_H1','financial':{'statement_type':'CFS','owner_net_income_ttm':100},'diagnostic':{}}}
  h={'000001':{'period':'2025_H1','identity':[2025,'11012','CFS'],'status':'COMPLETE','cfo_ttm_krw':1000}}
  self.assertIsNone(reconcile(x,h)['000001']['financial']['cfo_ttm'])
 def test_cfo_match(self):
  x={'000001':{'period':'2026_H1','financial':{'statement_type':'CFS','owner_net_income_ttm':100},'diagnostic':{}}}
  h={'000001':{'period':'2026_H1','identity':[2026,'11012','CFS'],'status':'COMPLETE','cfo_ttm_krw':200}}
  self.assertEqual(reconcile(x,h)['000001']['diagnostic']['cfo_to_owner_net_income_provisional'],2)
if __name__=='__main__':unittest.main()
