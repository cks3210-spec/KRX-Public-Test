import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'v5'))
from v5_stage3_adapter import adapt, process

class Stage3Tests(unittest.TestCase):
    def setUp(self):
        self.h = {'status':'COMPLETE','ISU_NM':'예시','period':'2026_H1','identity':['2026','11012','CFS','time'],'formula':'FY_prior + current_YTD - previous_YTD','roe_ttm_pct_diagnostic':3.58,'ttm_net_income_krw':100,'cfo_ttm_krw':200}
    def test_preserves_legacy(self):
        r=adapt('000020',self.h)
        self.assertEqual(r['legacy_roe_pct_diagnostic'],3.58)
        self.assertIsNone(r['owner_roe_pct_provisional'])
        self.assertIsNone(r['investment_grade'])
    def test_no_fabricated_valuation(self):
        r=adapt('000020',self.h)
        self.assertIsNone(r['per_provisional'])
        self.assertIsNone(r['pbr_provisional'])
    def test_missing_source_flag(self):
        h=dict(self.h,status='FAILED',identity=None)
        r=adapt('000020',h)
        self.assertIn('INCOMPLETE_HISTORY_RECORD',r['flags'])
        self.assertIn('STATEMENT_IDENTITY_MISSING',r['flags'])
    def test_real_shape_summary(self):
        rows,s=process({'000020':self.h,'000050':dict(self.h,status='PARTIAL')})
        self.assertEqual(s['processed_records'],2)
        self.assertEqual(s['complete_history_records'],1)
        self.assertEqual(s['grades_issued'],0)
    def test_empty(self):
        rows,s=process({})
        self.assertEqual(rows,[])
        self.assertEqual(s['processed_records'],0)
if __name__=='__main__':unittest.main()
