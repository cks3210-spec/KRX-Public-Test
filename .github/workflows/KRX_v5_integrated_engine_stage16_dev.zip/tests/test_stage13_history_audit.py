import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'v5'))
from v5_stage13_history_audit import audit

class TestHistoryAudit(unittest.TestCase):
    def test_valid(self):
        summary, rows = audit({'000001': {'status': 'COMPLETE', 'identity': ['2026','11012','CFS'], 'formula': 'FY_prior + current_YTD - previous_YTD', 'prior_fy_net_income_krw': 20, 'current_ytd_net_income_krw': 7, 'previous_ytd_net_income_krw': 5, 'ttm_net_income_krw': 22, 'cfo_ttm_krw': 12, 'roe_ttm_pct_diagnostic': 3.0, 'equity_end_krw': 100}})
        self.assertEqual(summary['companies'], 1)
        self.assertEqual(rows['000001']['flags'], [])
        self.assertIsNone(rows['000001']['investment_grade'])
    def test_mismatch(self):
        _, rows = audit({'1': {'status':'PARTIAL', 'identity':['2026','11012','OFS'], 'formula':'FY_prior + current_YTD - previous_YTD', 'prior_fy_net_income_krw':20, 'current_ytd_net_income_krw':7, 'previous_ytd_net_income_krw':5, 'ttm_net_income_krw':23, 'equity_end_krw':-1}})
        self.assertIn('TTM_ARITHMETIC_MISMATCH', rows['1']['flags'])
        self.assertIn('NONPOSITIVE_EQUITY', rows['1']['flags'])
    def test_missing_and_bad_record(self):
        _, rows = audit({'a': {}, 'b': None})
        self.assertIn('CFO_MISSING', rows['a']['flags'])
        self.assertIn('INVALID_RECORD', rows['b']['flags'])
if __name__ == '__main__': unittest.main()
