import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_financial_extension import evaluate
class ExtensionTests(unittest.TestCase):
 def setUp(self):
  self.f={'assets_current':1000,'liabilities_current':400,'equity_current':600,'revenue_ttm':500,'revenue_prior_ttm':400,'operating_income_ttm':50,'owner_net_income_ttm':30,'cfo_ttm':60,'owner_equity_current':550,'owner_equity_12m_prior':450,'period_end':'2026-06-30','statement_type':'CFS','source_reconciled':True}
  self.m={'market_cap_krw':3000,'asof':'2026-11-04'}
 def test_metrics(self):
  r=evaluate('1',self.f,self.m)
  self.assertEqual(r['roe_owner_ttm_pct_provisional'],6)
  self.assertEqual(r['revenue_growth_ttm_pct_provisional'],25)
  self.assertEqual(r['per_provisional'],100)
  self.assertIsNone(r['investment_grade'])
 def test_accounting_identity(self):
  f={**self.f,'liabilities_current':500}
  self.assertIn('BALANCE_SHEET_IDENTITY_MISMATCH',evaluate('1',f,self.m)['flags'])
 def test_negative_earnings(self):
  f={**self.f,'owner_net_income_ttm':-10}
  r=evaluate('1',f,self.m)
  self.assertIsNone(r['per_provisional'])
  self.assertIn('NONPOSITIVE_EARNINGS_PER_NA',r['flags'])
 def test_date_and_missing(self):
  r=evaluate('1',self.f,{'market_cap_krw':3000,'asof':'2025-01-01'})
  self.assertIn('MARKET_FINANCIAL_PERIOD_MISMATCH',r['flags'])
  self.assertIn('MISSING_REVENUE_PRIOR_TTM',evaluate('1',{**self.f,'revenue_prior_ttm':None},self.m)['flags'])
 def test_financial_sector(self):
  self.assertIn('SECTOR_SPECIFIC_RULES_REQUIRED',evaluate('1',{**self.f,'sector':'bank'},self.m)['flags'])
if __name__=='__main__':unittest.main()
