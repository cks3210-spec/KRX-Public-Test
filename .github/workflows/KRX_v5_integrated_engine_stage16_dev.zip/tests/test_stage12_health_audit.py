import unittest
from v5.v5_stage12_health_audit import audit
class AuditTests(unittest.TestCase):
    def row(self):
        return {'name':'TEST','period':'2026_H1','financial':{'assets_current':100,'liabilities_current':40,'equity_current':60,'owner_equity_current':55,'owner_equity_12m_prior':50,'owner_net_income_ttm':10,'cfo_ttm':12,'cfo_provenance':'HISTORY_MATCHED_PERIOD_AND_STATEMENT'},'diagnostic':{'roa_owner_ttm_pct_provisional':10,'debt_to_equity_pct_provisional':66.6667},'source_reconciled':False}
    def test_balanced(self):
        a=audit({'001':self.row()})['001'];self.assertEqual(a['checks']['balance_sheet'],'PASS');self.assertIsNone(a['investment_grade'])
    def test_mismatch(self):
        x=self.row();x['financial']['assets_current']=99;self.assertIn('BALANCE_SHEET_MISMATCH',audit({'001':x})['001']['flags'])
    def test_cfo_mismatch(self):
        x=self.row();x['financial']['cfo_provenance']='NOT_CONNECTED';self.assertIn('CFO_PERIOD_OR_SOURCE_REVIEW',audit({'001':x})['001']['flags'])
    def test_negative_cash_flow(self):
        x=self.row();x['financial']['cfo_ttm']=-2;self.assertIn('NEGATIVE_OPERATING_CASH_FLOW',audit({'001':x})['001']['flags'])
    def test_missing(self):
        x=self.row();x['financial']['equity_current']=None;self.assertEqual(audit({'001':x})['001']['checks']['balance_sheet'],'MISSING')
if __name__=='__main__':unittest.main()
