import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_dart_source_adapter import select,ttm,normalize

def r(id,section='BS',v='100',add='100',detail='-'):
 return {'account_id':id,'sj_div':section,'thstrm_amount':v,'thstrm_add_amount':add,'account_detail':detail}
class TestDartAdapter(unittest.TestCase):
 def test_assets(self):self.assertEqual(select([r('ifrs-full_Assets')],'assets_current','thstrm_amount'),100)
 def test_conflicting_duplicate(self):self.assertIsNone(select([r('ifrs-full_Assets',v='100'),r('ifrs-full_Assets',v='200')],'assets_current','thstrm_amount'))
 def test_member_exclusion(self):self.assertIsNone(select([r('ifrs-full_Assets',detail='member')],'assets_current','thstrm_amount'))
 def test_ttm(self):
  i='ifrs-full_Revenue';self.assertEqual(ttm('revenue',[r(i,'IS','10','40')],[r(i,'IS','80','80')],[r(i,'IS','20','30')]),90)
 def test_no_invented_growth(self):
  x=normalize('000001',{'year':2026,'report_code':'11012','fs_div':'CFS','current_rows':[r('ifrs-full_Assets')]})
  self.assertIsNone(x['financial']['revenue_prior_ttm']);self.assertIsNone(x['financial']['investment_grade'])
 def test_bad_identity(self):self.assertEqual(normalize('a',{'year':2026,'report_code':'bad','fs_div':'CFS'})['status'],'INVALID_IDENTITY')
if __name__=='__main__':unittest.main()
