import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v5'))
from v5_stage15_live_audit import diagnose
class Tests(unittest.TestCase):
 def sample(self):
  return {'000001':{'ISU_NM':'A','status':'COMPLETE','identity':['2026','11012','CFS'],'period':'2026_H1','ttm_net_income_krw':3,'cfo_ttm_krw':4,'roe_ttm_pct_diagnostic':2,'equity_end_krw':10,'formula':'FY_prior + current_YTD - previous_YTD','prior_fy_net_income_krw':2,'current_ytd_net_income_krw':2,'previous_ytd_net_income_krw':1}}
 def test_new_code(self):
  s,r,d,t=diagnose(self.sample(),{});self.assertEqual(d['added_codes'],['000001']);self.assertEqual(s['new_codes'],1)
 def test_removed(self):
  s,r,d,t=diagnose({}, {'000001':{'flags':[]}});self.assertEqual(d['removed_codes'],['000001'])
 def test_flag_resolution(self):
  s,r,d,t=diagnose(self.sample(), {'000001':{'flags':['CFO_MISSING'],'period':'2026_H1'}});self.assertEqual(d['resolved_codes'],['000001'])
 def test_nonpositive_equity(self):
  h=self.sample();h['000001']['equity_end_krw']=-1;s,r,d,t=diagnose(h,{});self.assertEqual(t[0]['category'],'CRITICAL')
 def test_ofs(self):
  h=self.sample();h['000001']['identity'][2]='OFS';s,r,d,t=diagnose(h,{});self.assertEqual(t[0]['category'],'STATEMENT_REVIEW')
 def test_no_grade(self):
  s,r,d,t=diagnose(self.sample(),{});self.assertIsNone(r['000001']['investment_grade'])
if __name__=='__main__':unittest.main()
