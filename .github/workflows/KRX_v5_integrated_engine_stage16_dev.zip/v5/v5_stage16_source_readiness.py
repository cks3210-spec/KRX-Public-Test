"""Stage 16 read-only source-readiness and recovery triage. Not a DART reconciliation."""
import json,argparse
from pathlib import Path
from collections import Counter

def review(history):
    rows=[]
    for code,h in sorted(history.items()):
        if not isinstance(h,dict):
            rows.append(dict(code=code,category='INVALID_RECORD',reason='Not an object',grade=None,source_reconciled=False));continue
        ident=h.get('identity');basis=ident[2] if isinstance(ident,list) and len(ident)>=3 else None
        flags=[]
        if h.get('status')!='COMPLETE': flags.append('PARTIAL_RECOLLECT_REQUIRED')
        if basis=='OFS': flags.append('OFS_SOURCE_PROOF_REQUIRED')
        if basis not in ('CFS','OFS'): flags.append('STATEMENT_BASIS_UNKNOWN')
        if h.get('equity_end_krw') is not None and h['equity_end_krw']<=0: flags.append('NONPOSITIVE_EQUITY')
        if h.get('ttm_net_income_krw') is None: flags.append('NET_INCOME_MISSING')
        if h.get('cfo_ttm_krw') is None: flags.append('CFO_MISSING')
        if h.get('roe_ttm_pct_diagnostic') is None: flags.append('ROE_MISSING')
        if h.get('period') not in ('2026_H1','2026_Q3','2026_Q1','2025_H1','2025_Q1'):flags.append('PERIOD_REVIEW')
        if flags:
            category='RECOLLECT' if 'PARTIAL_RECOLLECT_REQUIRED' in flags else 'OFS_PROOF' if 'OFS_SOURCE_PROOF_REQUIRED' in flags else 'REVIEW'
            rows.append(dict(code=code,name=h.get('ISU_NM'),period=h.get('period'),basis=basis,category=category,flags=flags,grade=None,source_reconciled=False))
    summary={'total':len(history),'complete':sum(isinstance(v,dict) and v.get('status')=='COMPLETE' for v in history.values()),'partial':sum(isinstance(v,dict) and v.get('status')!='COMPLETE' for v in history.values()),'flagged_companies':len(rows),'categories':dict(Counter(x['category'] for x in rows)),'source_reconciled':False,'investment_grades_created':0,'source_proof_required':True}
    return summary,rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',default='stage16_report');a=p.parse_args();h=json.loads(Path(a.input).read_text(encoding='utf-8'));s,r=review(h);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    for n,x in [('summary',s),('source_readiness',r)]: (out/(n+'.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(s,ensure_ascii=False))
if __name__=='__main__':main()
