"""Read-only cross-metric audit of provisional financial statements.

Does not produce recommendations, rankings or investment grades.
"""
import argparse
import json
from pathlib import Path
try:
    from .v5_stage10_reconcile import finite
except ImportError:
    from v5_stage10_reconcile import finite

METRICS = ('roe_owner_ttm_pct_provisional','roa_owner_ttm_pct_provisional',
           'debt_to_equity_pct_provisional','operating_margin_pct_provisional',
           'revenue_growth_ttm_pct_provisional','cfo_to_owner_net_income_provisional')

def audit(rows):
    output = {}
    for code, source in sorted(rows.items()):
        f = source.get('financial') or {}
        d = source.get('diagnostic') or {}
        flags = set(d.get('flags') or [])
        a, l, e = (f.get(k) for k in ('assets_current','liabilities_current','equity_current'))
        own_ni = f.get('owner_net_income_ttm')
        own_eq = f.get('owner_equity_current')
        prior_eq = f.get('owner_equity_12m_prior')
        cfo = f.get('cfo_ttm')
        checks = {}
        checks['balance_sheet'] = 'PASS' if all(finite(v) for v in (a,l,e)) and a == l+e else ('FAIL' if all(finite(v) for v in (a,l,e)) else 'MISSING')
        checks['equity_positive'] = 'PASS' if finite(e) and e>0 else ('FAIL' if finite(e) else 'MISSING')
        checks['owner_equity_basis'] = 'PASS' if all(finite(v) and v>0 for v in (own_eq,prior_eq)) else 'REVIEW'
        checks['cfo_period'] = 'PASS' if finite(cfo) and f.get('cfo_provenance')=='HISTORY_MATCHED_PERIOD_AND_STATEMENT' else 'REVIEW'
        checks['source_reconciliation'] = 'PASS' if source.get('source_reconciled') is True else 'PENDING'
        if checks['balance_sheet']=='FAIL': flags.add('BALANCE_SHEET_MISMATCH')
        if checks['equity_positive']=='FAIL': flags.add('NONPOSITIVE_EQUITY')
        if checks['owner_equity_basis']!='PASS': flags.add('OWNER_EQUITY_BASIS_REVIEW')
        if checks['cfo_period']!='PASS': flags.add('CFO_PERIOD_OR_SOURCE_REVIEW')
        if finite(cfo) and cfo<0: flags.add('NEGATIVE_OPERATING_CASH_FLOW')
        if finite(own_ni) and own_ni>0 and finite(cfo) and cfo<own_ni: flags.add('CFO_BELOW_OWNER_PROFIT')
        metrics={k:d.get(k) if finite(d.get(k)) else None for k in METRICS}
        # Recalculate two key ratios independently, to detect accidental data joins.
        expected_debt=round(l/e*100,4) if finite(l) and finite(e) and e>0 else None
        expected_roa=round(own_ni/a*100,4) if finite(own_ni) and finite(a) and a>0 else None
        checks['debt_ratio_arithmetic']='PASS' if expected_debt is not None and metrics['debt_to_equity_pct_provisional']==expected_debt else 'REVIEW'
        checks['roa_arithmetic']='PASS' if expected_roa is not None and metrics['roa_owner_ttm_pct_provisional']==expected_roa else 'REVIEW'
        if checks['debt_ratio_arithmetic']=='REVIEW': flags.add('DEBT_RATIO_RECALC_REVIEW')
        if checks['roa_arithmetic']=='REVIEW': flags.add('ROA_RECALC_REVIEW')
        output[code]={'name':source.get('name'),'period':source.get('period'), 'metrics_provisional':metrics,
                      'checks':checks,'flags':sorted(flags),'investment_grade':None,'source_reconciled':False}
    return output

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',default='stage12_diagnostics');args=ap.parse_args()
    rows=json.loads(Path(args.input).read_text(encoding='utf8'))
    result=audit(rows)
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    (out/'diagnostics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    checks=('balance_sheet','cfo_period','debt_ratio_arithmetic','roa_arithmetic')
    summary={'companies':len(result),'checks_passed':{c:sum(r['checks'][c]=='PASS' for r in result.values()) for c in checks},
             'flag_counts':{flag:sum(flag in r['flags'] for r in result.values()) for flag in sorted({f for r in result.values() for f in r['flags']})},
             'investment_grades':0,'source_reconciled':False}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__': main()
