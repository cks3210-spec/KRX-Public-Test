"""Read-only stage 10 reconciliation of five-period pilot output and history CFO.
Never assigns investment grades or asserts independent filing reconciliation.
"""
import argparse, json, math
from pathlib import Path

def finite(x):
    return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)

def transition(current,prior):
    if not finite(current) or not finite(prior): return 'DATA_MISSING'
    if prior<0 and current>0: return 'TURNED_PROFIT'
    if prior>0 and current<0: return 'TURNED_LOSS'
    if prior<0 and current<0: return 'LOSS_CONTINUES'
    if prior>0 and current>0: return 'PROFIT_CONTINUES'
    if prior==0 or current==0: return 'ZERO_BOUNDARY'
    return 'UNCHANGED'

def reconcile(records,history=None):
    history=history or {}; out={}
    for code,original in sorted(records.items()):
        row=dict(original); f=dict(row.get('financial') or {}); d=dict(row.get('diagnostic') or {})
        required=('assets_current','liabilities_current','equity_current','owner_equity_current','owner_equity_12m_prior','revenue_ttm','operating_income_ttm','owner_net_income_ttm','revenue_prior_ttm','operating_income_prior_ttm','owner_net_income_prior_ttm')
        missing=[k for k in required if not finite(f.get(k))]
        h=history.get(code) or {}
        identity=h.get('identity') or []
        period_match=bool(h.get('period') and h.get('period')==row.get('period') and len(identity)>=3 and identity[2]==f.get('statement_type'))
        cfo=h.get('cfo_ttm_krw') if period_match and h.get('status')=='COMPLETE' else None
        if finite(cfo):
            f['cfo_ttm']=cfo
            f['cfo_provenance']='HISTORY_MATCHED_PERIOD_AND_STATEMENT'
        else:
            f['cfo_ttm']=None
            f['cfo_provenance']='NOT_CONNECTED_OR_PERIOD_MISMATCH'
        ni=f.get('owner_net_income_ttm')
        d['cfo_to_owner_net_income_provisional']=round(cfo/ni,4) if finite(cfo) and finite(ni) and ni>0 else None
        flags=set(d.get('flags') or [])
        flags.discard('MISSING_REVENUE_PRIOR_TTM')
        flags.discard('MISSING_CFO_TTM')
        if not finite(f.get('revenue_prior_ttm')):flags.add('MISSING_REVENUE_PRIOR_TTM')
        if not finite(cfo):flags.add('MISSING_CFO_TTM')
        if finite(ni) and ni<=0:flags.add('CFO_RATIO_NONPOSITIVE_OWNER_PROFIT')
        transitions={k:transition(f.get(k+'_ttm'),f.get(k+'_prior_ttm')) for k in ('operating_income','owner_net_income')}
        for k,t in transitions.items():
            if t in ('TURNED_PROFIT','TURNED_LOSS','LOSS_CONTINUES','ZERO_BOUNDARY'):flags.add(k.upper()+'_'+t)
        f['missing']=missing+(['cfo_ttm'] if not finite(cfo) else [])
        f['source_reconciled']=False;f['investment_grade']=None
        d['flags']=sorted(flags);d['investment_grade']=None
        row.update(financial=f,diagnostic=d,profit_transitions=transitions,investment_grade=None,source_reconciled=False)
        out[code]=row
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',required=True);p.add_argument('--history');p.add_argument('--output',default='v5_stage10_output');a=p.parse_args()
    data=json.loads(Path(a.pilot).read_text(encoding='utf8'))
    hist=json.loads(Path(a.history).read_text(encoding='utf8')) if a.history else {}
    rows=reconcile(data,hist); out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    (out/'diagnostics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
    summary={'companies':len(rows),'stale_revenue_missing':sum('revenue_prior_ttm' in x['financial']['missing'] and finite(x['financial'].get('revenue_prior_ttm')) for x in rows.values()),'cfo_connected':sum(finite(x['financial']['cfo_ttm']) for x in rows.values()),'profit_turns':{t:sum(t in x['profit_transitions'].values() for x in rows.values()) for t in ('TURNED_PROFIT','TURNED_LOSS','LOSS_CONTINUES')},'investment_grades':0,'source_reconciled':False}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
