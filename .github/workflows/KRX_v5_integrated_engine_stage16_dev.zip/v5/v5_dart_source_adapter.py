#!/usr/bin/env python3
"""Read-only DART statement row normalization for v5; no API calls or scoring.

Input JSON maps company code to {year, report_code, fs_div, current_rows,
prior_fy_rows, prior_ytd_rows}. Each rows array comes from OpenDART
fnlttSinglAcntAll.json's `list` for the requested period.
"""
import argparse
import json
from pathlib import Path

IDS = {
 'assets_current': ('BS', {'ifrs-full_Assets','ifrs_Assets'}),
 'liabilities_current': ('BS', {'ifrs-full_Liabilities','ifrs_Liabilities'}),
 'equity_current': ('BS', {'ifrs-full_Equity','ifrs_Equity'}),
 'owner_equity_current': ('BS', {'ifrs-full_EquityAttributableToOwnersOfParent','ifrs_EquityAttributableToOwnersOfParent'}),
 'revenue': ('IS/CIS', {'ifrs-full_Revenue','ifrs_Revenue','ifrs-full_RevenueFromContractsWithCustomers'}),
 'operating_income': ('IS/CIS', {'dart_OperatingIncomeLoss'}),
 'owner_net_income': ('IS/CIS', {'ifrs-full_ProfitLossAttributableToOwnersOfParent','ifrs_ProfitLossAttributableToOwnersOfParent'}),
}

def amount(x):
 if x is None or isinstance(x,bool): return None
 try: return int(str(x).replace(',','').strip())
 except (ValueError,TypeError): return None

def select(rows, metric, field):
 section,ids=IDS[metric]; sections=section.split('/')
 found=[]
 for r in rows:
  if r.get('sj_div') not in sections or r.get('account_id') not in ids:continue
  # Explicit account details other than '-' are potentially member-specific.
  if r.get('account_detail') not in (None,'','-'):continue
  val=amount(r.get(field))
  if val is not None:found.append(val)
 # Duplicate same-value rows are acceptable; conflicting values are not.
 return found[0] if found and len(set(found))==1 else None

def ttm(metric,now,fy,prev):
 a=select(now,metric,'thstrm_add_amount')
 b=select(fy,metric,'thstrm_amount')
 c=select(prev,metric,'thstrm_add_amount')
 return b+a-c if None not in (a,b,c) else None

def normalize(code,record):
 now=record.get('current_rows') or []; fy=record.get('prior_fy_rows') or []; prev=record.get('prior_ytd_rows') or []
 report=record.get('report_code'); year=record.get('year'); fs=record.get('fs_div')
 if report not in ('11013','11012','11014') or fs not in ('CFS','OFS') or not isinstance(year,int):
  return {'code':code,'status':'INVALID_IDENTITY','investment_grade':None}
 vals={k:select(now,k,'thstrm_amount') for k in ('assets_current','liabilities_current','equity_current','owner_equity_current')}
 vals['owner_equity_12m_prior']=select(prev,'owner_equity_current','thstrm_amount')
 for metric,key in [('revenue','revenue_ttm'),('operating_income','operating_income_ttm'),('owner_net_income','owner_net_income_ttm')]:
  vals[key]=ttm(metric,now,fy,prev)
 vals['revenue_prior_ttm']=None # Requires FY-2 and prior-year comparable YTD; never infer from one YTD.
 vals['period_end']=record.get('period_end');vals['statement_type']=fs
 vals['source_reconciled']=False;vals['investment_grade']=None
 vals['missing']=[k for k,v in vals.items() if v is None]
 return {'code':code,'status':'PROVISIONAL_SOURCE_REVIEW','financial':vals}

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 data=json.loads(Path(a.input).read_text(encoding='utf-8'))
 out={k:normalize(k,v) for k,v in data.items()}
 Path(a.output).parent.mkdir(parents=True,exist_ok=True)
 Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'companies':len(out),'provisional':sum(x['status']=='PROVISIONAL_SOURCE_REVIEW' for x in out.values()),'graded':0},ensure_ascii=False))
if __name__=='__main__':main()
