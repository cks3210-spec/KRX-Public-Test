#!/usr/bin/env python3
"""Read-only v5 integration: diagnostics only; never alters trading or existing history."""
import argparse, csv, json, math
from pathlib import Path


def numeric(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def ratio(n, d, scale=100):
    return round(n / d * scale, 4) if numeric(n) and numeric(d) and d > 0 else None


def calculate(code, history, pilot=None, price=None):
    h = history or {}; p = pilot or {}; price = price or {}
    flags = []
    status = h.get('status')
    if status not in ('COMPLETE', 'PARTIAL'):
        flags.append('HISTORY_NOT_VERIFIED')
    old_roe = h.get('roe_ttm_pct_diagnostic')
    new_roe = p.get('roe_owner_ttm_pct') if p.get('status') == 'ARITHMETIC_READY_SOURCE_REVIEW_REQUIRED' else None
    if numeric(old_roe) and numeric(new_roe) and abs(old_roe-new_roe) >= 2:
        flags.append('ROE_BASIS_DIFFERENCE_2PP')
    if new_roe is not None:
        flags.append('ROE_SOURCE_REVIEW_REQUIRED')
    else:
        flags.append('OWNER_ROE_NOT_AVAILABLE')
    cfo = h.get('cfo_ttm_krw'); ni = h.get('ttm_net_income_krw')
    if not numeric(cfo): flags.append('CFO_MISSING')
    if not numeric(ni): flags.append('NET_INCOME_MISSING')
    # Ratios needing unavailable asset, revenue, share count or market prices remain null.
    assets = h.get('assets_end_krw')
    roa = ratio(ni, assets) if numeric(assets) else None
    if roa is None: flags.append('ROA_INPUT_MISSING')
    market_cap = price.get('market_cap_krw')
    # Only owner net income is appropriate for owner earnings multiple.
    owner_ni = p.get('owner_ttm_net_income') if new_roe is not None else None
    per = ratio(market_cap, owner_ni, 1) if numeric(market_cap) and numeric(owner_ni) and owner_ni > 0 else None
    owner_eq = p.get('owner_equity_current') if new_roe is not None else None
    pbr = ratio(market_cap, owner_eq, 1) if numeric(market_cap) and numeric(owner_eq) else None
    if per is None or pbr is None: flags.append('VALUATION_INPUT_OR_RECONCILIATION_MISSING')
    if price and not price.get('asof'): flags.append('PRICE_ASOF_MISSING')
    # No production grades until source reconciliation and coverage gates are met.
    return {'code':code,'name':h.get('ISU_NM') or p.get('name'), 'period':h.get('period'),
            'legacy_roe_pct_diagnostic':old_roe,'owner_roe_pct_provisional':new_roe,
            'roe_delta_pp':round(new_roe-old_roe,4) if numeric(new_roe) and numeric(old_roe) else None,
            'ttm_net_income_krw':ni,'owner_ttm_net_income_krw':owner_ni,'cfo_ttm_krw':cfo,
            'cfo_to_ni':ratio(cfo, ni, 1), 'roa_pct_provisional':roa,
            'per_provisional':per,'pbr_provisional':pbr,'price_asof':price.get('asof'),
            'growth_pct':None,'financial_strength_score':None,'investment_grade':None,
            'source_reconciled':False,'flags':sorted(set(flags))}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--history',required=True)
    ap.add_argument('--pilot',action='append',default=[])
    ap.add_argument('--prices',default=None)
    ap.add_argument('--output',default='v5_integrated_output')
    args=ap.parse_args()
    hist=json.loads(Path(args.history).read_text(encoding='utf-8'))
    pilots={}
    for file in args.pilot:
        data=json.loads(Path(file).read_text(encoding='utf-8'))
        for p in data: pilots[p['code']]=p
    prices=json.loads(Path(args.prices).read_text(encoding='utf-8')) if args.prices else {}
    rows=[calculate(k,v,pilots.get(k),prices.get(k)) for k,v in sorted(hist.items())]
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    (out/'diagnostics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    summary={'history_count':len(rows),'owner_roe_provisional_count':sum(r['owner_roe_pct_provisional'] is not None for r in rows),
             'legacy_roe_count':sum(r['legacy_roe_pct_diagnostic'] is not None for r in rows),
             'cfo_count':sum(r['cfo_ttm_krw'] is not None for r in rows),
             'grades_issued':0,'mode':'READ_ONLY_DIAGNOSTICS',
             'limitations':['Source/restatement reconciliation pending','ROA requires asset inputs','PER/PBR require verified dated market cap and ownership basis','Growth requires aligned comparative financials']}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'diagnostics.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fields=['code','name','period','legacy_roe_pct_diagnostic','owner_roe_pct_provisional','roe_delta_pp','cfo_ttm_krw','roa_pct_provisional','per_provisional','pbr_provisional','investment_grade','flags']
        writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader()
        for row in rows:writer.writerow({**row,'flags':';'.join(row['flags'])})
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__': main()
