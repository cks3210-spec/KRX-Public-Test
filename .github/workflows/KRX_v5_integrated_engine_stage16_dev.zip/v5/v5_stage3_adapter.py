#!/usr/bin/env python3
"""Read-only bridge from actual v5-state history_metrics.json to stage2 diagnostics.
No fabricated fields: unavailable financial and market metrics remain null.
"""
import argparse, csv, json
from collections import Counter
from pathlib import Path
from v5_integrated_engine import calculate


def adapt(code, history):
    """Keep original account basis and period; never relabel legacy ROE as owner ROE."""
    h = dict(history)
    row = calculate(code, h)
    flags = set(row['flags'])
    identity = h.get('identity')
    if not isinstance(identity, list) or len(identity) < 3 or identity[2] not in ('CFS', 'OFS'):
        flags.add('STATEMENT_IDENTITY_MISSING')
    elif identity[2] == 'OFS':
        flags.add('SEPARATE_STATEMENT_REVIEW_REQUIRED')
    if h.get('cfo_missing_reason'):
        flags.add('CFO_SOURCE_MISSING_' + str(h['cfo_missing_reason'])[:50])
    if h.get('status') != 'COMPLETE':
        flags.add('INCOMPLETE_HISTORY_RECORD')
    if h.get('formula') != 'FY_prior + current_YTD - previous_YTD':
        flags.add('TTM_FORMULA_UNVERIFIED')
    # Guard against accidental use of legacy consolidated equity as owner equity.
    row['owner_roe_pct_provisional'] = None
    row['per_provisional'] = None
    row['pbr_provisional'] = None
    row['investment_grade'] = None
    row['source_reconciled'] = False
    row['flags'] = sorted(flags)
    return row


def process(history):
    if not isinstance(history, dict):
        raise ValueError('history must be a dictionary keyed by stock code')
    rows = [adapt(code, history[code]) for code in sorted(history) if isinstance(history[code], dict)]
    counts = Counter(f for row in rows for f in row['flags'])
    summary = {
        'input_records': len(history), 'processed_records': len(rows),
        'complete_history_records': sum(history[c].get('status') == 'COMPLETE' for c in history if isinstance(history[c], dict)),
        'legacy_roe_diagnostic_available': sum(r['legacy_roe_pct_diagnostic'] is not None for r in rows),
        'cfo_available': sum(r['cfo_ttm_krw'] is not None for r in rows),
        'owner_roe_verified': 0, 'grades_issued': 0,
        'mode': 'READ_ONLY_ACTUAL_HISTORY_BRIDGE', 'flag_counts': dict(sorted(counts.items())),
        'note': 'Legacy consolidated ROE is diagnostic only. Missing owner accounts, assets, revenue and dated market cap are not inferred.'
    }
    return rows, summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--history', required=True)
    parser.add_argument('--output', default='v5_stage3_output')
    args = parser.parse_args()
    history = json.loads(Path(args.history).read_text(encoding='utf-8'))
    rows, summary = process(history)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    (out/'diagnostics.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    fields = ['code','name','period','legacy_roe_pct_diagnostic','ttm_net_income_krw','cfo_ttm_krw','cfo_to_ni','investment_grade','flags']
    with (out/'diagnostics.csv').open('w', newline='', encoding='utf-8-sig') as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: ';'.join(row['flags']) if key == 'flags' else row.get(key) for key in fields})
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
