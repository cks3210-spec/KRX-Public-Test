#!/usr/bin/env python3
"""Independent v5 financial diagnostics; inputs are explicit, no production grades."""
import argparse,json,math
from datetime import date
from pathlib import Path

def num(v): return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def pct(a,b): return round(100*a/b,4) if num(a) and num(b) and b>0 else None
def multiple(a,b): return round(a/b,4) if num(a) and num(b) and b>0 else None

def evaluate(code,financial,market=None):
 f=financial or {}; m=market or {}; flags=[]
 def value(k):
  v=f.get(k)
  if not num(v): flags.append('MISSING_'+k.upper());return None
  return v
 assets=value('assets_current'); liabilities=value('liabilities_current')
 equity=value('equity_current'); revenue=value('revenue_ttm'); prior_revenue=value('revenue_prior_ttm')
 op=value('operating_income_ttm'); ni=value('owner_net_income_ttm'); cfo=value('cfo_ttm')
 owner_eq=value('owner_equity_current'); owner_eq_prior=value('owner_equity_12m_prior')
 if None not in (assets,liabilities,equity) and abs(assets-liabilities-equity)>max(1,abs(assets)*.0001):flags.append('BALANCE_SHEET_IDENTITY_MISMATCH')
 if any(x is not None and x<=0 for x in (assets,equity,owner_eq,owner_eq_prior)):flags.append('NONPOSITIVE_CAPITAL_BASE')
 roe=pct(2*ni,owner_eq+owner_eq_prior) if None not in (ni,owner_eq,owner_eq_prior) and owner_eq>0 and owner_eq_prior>0 else None
 roa=pct(ni,assets) if ni is not None and assets is not None else None
 debt=pct(liabilities,equity) if liabilities is not None and equity is not None else None
 opmargin=pct(op,revenue) if op is not None and revenue is not None else None
 growth=pct(revenue-prior_revenue,prior_revenue) if revenue is not None and prior_revenue is not None else None
 cash_quality=multiple(cfo,ni) if cfo is not None and ni is not None else None
 cap=m.get('market_cap_krw'); asof=m.get('asof'); period=f.get('period_end')
 if not isinstance(asof,str) or not isinstance(period,str):flags.append('DATED_MARKET_OR_PERIOD_MISSING')
 else:
  try:
   md=date.fromisoformat(asof); fd=date.fromisoformat(period)
   if md<fd or (md-fd).days>450:flags.append('MARKET_FINANCIAL_PERIOD_MISMATCH')
  except ValueError:flags.append('INVALID_DATE')
 if not num(cap) or cap<=0:flags.append('MARKET_CAP_MISSING')
 if f.get('source_reconciled') is not True:flags.append('SOURCE_RECONCILIATION_PENDING')
 if f.get('statement_type') not in ('CFS','OFS'):flags.append('STATEMENT_TYPE_UNVERIFIED')
 if f.get('sector') in ('financial','insurance','bank','securities'):flags.append('SECTOR_SPECIFIC_RULES_REQUIRED')
 per=multiple(cap,ni) if num(cap) and cap>0 and ni is not None else None
 pbr=multiple(cap,owner_eq) if num(cap) and cap>0 and owner_eq is not None else None
 if ni is not None and ni<=0:flags.append('NONPOSITIVE_EARNINGS_PER_NA')
 if growth is None:flags.append('GROWTH_COMPARATIVE_UNAVAILABLE')
 return {'code':code,'period_end':period,'roe_owner_ttm_pct_provisional':roe,'roa_owner_ttm_pct_provisional':roa,'debt_to_equity_pct_provisional':debt,'operating_margin_pct_provisional':opmargin,'revenue_growth_ttm_pct_provisional':growth,'cfo_to_owner_net_income_provisional':cash_quality,'per_provisional':per,'pbr_provisional':pbr,'investment_grade':None,'flags':sorted(set(flags))}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--financials',required=True);ap.add_argument('--markets');ap.add_argument('--output',default='v5_financial_output');args=ap.parse_args()
 financials=json.loads(Path(args.financials).read_text(encoding='utf-8'));markets=json.loads(Path(args.markets).read_text(encoding='utf-8')) if args.markets else {}
 rows=[evaluate(k,v,markets.get(k)) for k,v in sorted(financials.items())]
 out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 (out/'diagnostics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
 summary={'companies':len(rows),'grade_count':0,'mode':'READ_ONLY','flags':{flag:sum(flag in row['flags'] for row in rows) for flag in sorted({x for row in rows for x in row['flags']})}}
 (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
