#!/usr/bin/env python3
"""Read-only join of one-period OpenDART pilot snapshot and existing history.
No annualization of H1 values, no attribution of consolidated net income.
"""
import argparse, json
from pathlib import Path
from v5_financial_extension import evaluate

def bridge(sample, history=None):
    history=history or {}; output={}
    for code,p in sorted(sample.items()):
        m=p.get('metrics') or {}; h=history.get(code) or {}
        f={'assets_current':m.get('assets'), 'liabilities_current':m.get('liabilities'),
           'equity_current':m.get('equity'), 'owner_equity_current':m.get('owner_equity'),
           'owner_equity_12m_prior':None,
           'revenue_ttm':None,'revenue_prior_ttm':None,'operating_income_ttm':None,
           'owner_net_income_ttm':None,'cfo_ttm':h.get('cfo_ttm_krw'),
           'period_end':None,'statement_type':(h.get('identity') or [None,None,None])[2],
           'source_reconciled':False}
        d=evaluate(code,f)
        flags=set(d['flags'])
        if p.get('status')!='PROVISIONAL':flags.add('PILOT_FETCH_UNSUCCESSFUL')
        if m.get('assets') is not None and m.get('liabilities') is not None and m.get('equity') is not None:
            if m['assets']==m['liabilities']+m['equity']:flags.add('BALANCE_IDENTITY_EXACT_MATCH')
        flags.add('SNAPSHOT_NOT_TTM')
        flags.add('SOURCE_RECONCILIATION_PENDING')
        d.update({'name':p.get('name'),'reported_period':p.get('period'),
                  'snapshot':m,'history_status':h.get('status'),
                  'owner_equity_minus_total_equity_krw':(m['owner_equity']-m['equity'] if isinstance(m.get('owner_equity'),int) and isinstance(m.get('equity'),int) else None),
                  'flags':sorted(flags),'investment_grade':None})
        output[code]=d
    return output

def main():
    a=argparse.ArgumentParser();a.add_argument('--pilot',required=True);a.add_argument('--history');a.add_argument('--output',default='v5_stage6_output');args=a.parse_args()
    sample=json.loads(Path(args.pilot).read_text(encoding='utf-8'))
    history=json.loads(Path(args.history).read_text(encoding='utf-8')) if args.history else {}
    rows=bridge(sample,history)
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    (out/'diagnostics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    summary={'companies':len(rows),'six_field_complete':sum(len(v['snapshot'])>=6 and all(v['snapshot'].get(k) is not None for k in ('assets','liabilities','equity','owner_equity','revenue','owner_profit')) for v in rows.values()),'balance_exact':sum('BALANCE_IDENTITY_EXACT_MATCH' in v['flags'] for v in rows.values()),'owner_equity_gt_total':sum((v['owner_equity_minus_total_equity_krw'] or 0)>0 for v in rows.values()),'ttm_verified':0,'investment_grades':0,'mode':'READ_ONLY'}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
