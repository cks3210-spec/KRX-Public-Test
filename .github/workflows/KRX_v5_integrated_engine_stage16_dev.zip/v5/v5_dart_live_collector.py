#!/usr/bin/env python3
"""Independent limited OpenDART fetch for v5. Does not alter production data."""
import argparse, io, json, os, time, urllib.parse, urllib.request, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
from v5_dart_source_adapter import normalize
BASE='https://opendart.fss.or.kr/api/'

def request(endpoint, params=None, binary=False):
    key=os.environ.get('DART_API_KEY')
    if not key: raise RuntimeError('DART_API_KEY secret is required')
    url=BASE+endpoint+'?'+urllib.parse.urlencode({'crtfc_key':key,**(params or {})})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url,timeout=40) as response: raw=response.read()
            if binary:return raw
            data=json.loads(raw)
            if data.get('status')!='000':raise RuntimeError('DART status '+str(data.get('status')))
            return data['list']
        except (OSError, ValueError, RuntimeError):
            if attempt==2:raise
            time.sleep(2**attempt)

def corp_mapping(blob):
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        name=next(n for n in z.namelist() if n.lower().endswith('.xml'))
        root=ET.fromstring(z.read(name))
    return {e.findtext('stock_code','').strip():e.findtext('corp_code','').strip() for e in root.findall('list') if e.findtext('stock_code','').strip()}

def collect(history, mapping, limit=10, sleep=.3, fetch=request):
    output={}; attempts=0
    for code,h in sorted(history.items()):
        if attempts>=limit:break
        if not isinstance(h,dict) or h.get('status') not in ('COMPLETE','PARTIAL'):continue
        identity=h.get('identity') or []
        if len(identity)<3 or identity[2] not in ('CFS','OFS') or identity[1] not in ('11013','11012','11014') or not str(identity[0]).isdigit():continue
        corp=mapping.get(code)
        if not corp:continue
        attempts+=1
        year=int(identity[0]);report=identity[1];fs=identity[2]
        record={'year':year,'report_code':report,'fs_div':fs,'period_end':h.get('period')}
        try:
            for field,y,r in [('current_rows',year,report),('prior_fy_rows',year-1,'11011'),('prior_ytd_rows',year-1,report)]:
                record[field]=fetch('fnlttSinglAcntAll.json',{'corp_code':corp,'bsns_year':str(y),'reprt_code':r,'fs_div':fs})
                if sleep:time.sleep(sleep)
            norm=normalize(code,record)
            norm['name']=h.get('ISU_NM');norm['source_identity']={'year':year,'report':report,'fs':fs}
            output[code]=norm
        except Exception as exc:
            output[code]={'code':code,'name':h.get('ISU_NM'),'status':'FETCH_ERROR','error_type':type(exc).__name__,'error':str(exc)[:140],'investment_grade':None}
    return output

def main():
    p=argparse.ArgumentParser();p.add_argument('--history',required=True);p.add_argument('--output',default='v5_stage5_output');p.add_argument('--limit',type=int,default=10);p.add_argument('--sleep',type=float,default=.3)
    args=p.parse_args()
    if not 1<=args.limit<=50:p.error('limit must be between 1 and 50')
    history=json.loads(Path(args.history).read_text(encoding='utf-8'))
    mapping=corp_mapping(request('corpCode.xml',binary=True))
    results=collect(history,mapping,args.limit,args.sleep)
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    (out/'dart_provisional.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    counts={s:sum(x['status']==s for x in results.values()) for s in sorted({x['status'] for x in results.values()})}
    summary={'requested_limit':args.limit,'processed':len(results),'status_counts':counts,'graded':0,'source_verified':False,'mode':'READ_ONLY_MANUAL_DIAGNOSTIC'}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
