"""Five-period OpenDART TTM growth extension. Read-only; no grades."""
from v5_dart_source_adapter import select, ttm
from v5_financial_extension import evaluate

def prior_ttm(metric, prior_ytd_rows, fy_two_years_ago_rows, two_years_ago_ytd_rows):
    """TTM at prior-year same quarter = FY(Y-2)+YTD(Y-1)-YTD(Y-2)."""
    return ttm(metric, prior_ytd_rows, fy_two_years_ago_rows, two_years_ago_ytd_rows)

def extend(code, record):
    financial=dict(record.get('financial') or {})
    periods=record.get('additional_periods') or {}
    for metric,key in [('revenue','revenue_prior_ttm'),('operating_income','operating_income_prior_ttm'),('owner_net_income','owner_net_income_prior_ttm')]:
        financial[key]=prior_ttm(metric, periods.get('prior_ytd_rows') or [], periods.get('fy_two_years_ago_rows') or [], periods.get('two_years_ago_ytd_rows') or [])
    financial['source_reconciled']=False
    financial['investment_grade']=None
    result=evaluate(code,financial)
    def growth(current,prior):
        if not isinstance(current,(int,float)) or not isinstance(prior,(int,float)) or prior<=0:return None
        return round((current-prior)/prior*100,4)
    result['operating_income_growth_ttm_pct_provisional']=growth(financial.get('operating_income_ttm'),financial.get('operating_income_prior_ttm'))
    result['owner_net_income_growth_ttm_pct_provisional']=growth(financial.get('owner_net_income_ttm'),financial.get('owner_net_income_prior_ttm'))
    if result['operating_income_growth_ttm_pct_provisional'] is None:result['flags'].append('OPERATING_INCOME_GROWTH_UNAVAILABLE')
    if result['owner_net_income_growth_ttm_pct_provisional'] is None:result['flags'].append('OWNER_NET_INCOME_GROWTH_UNAVAILABLE')
    result['flags']=sorted(set(result['flags']))
    result['investment_grade']=None
    return {'code':code,'financial':financial,'diagnostic':result,'status':'PROVISIONAL_SOURCE_REVIEW','investment_grade':None}
