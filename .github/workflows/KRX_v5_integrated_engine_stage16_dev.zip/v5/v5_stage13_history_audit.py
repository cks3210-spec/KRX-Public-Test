"""Read-only quality audit for v5-state/v5_history/history_metrics.json.

Stored arithmetic checks are NOT independent OpenDART source reconciliation.
Never produces investment grades.
"""
import argparse
import json
import math
from collections import Counter
from pathlib import Path


def valid(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def audit(history):
    rows = {}
    for code, h in sorted(history.items()):
        if not isinstance(h, dict):
            rows[code] = {'flags': ['INVALID_RECORD'], 'investment_grade': None, 'source_reconciled': False}
            continue
        flags = []
        identity = h.get('identity')
        if not isinstance(identity, list) or len(identity) < 3 or identity[2] not in ('CFS', 'OFS'):
            flags.append('STATEMENT_IDENTITY_MISSING')
        elif identity[2] == 'OFS':
            flags.append('SEPARATE_STATEMENT_REVIEW')
        if h.get('status') != 'COMPLETE':
            flags.append('INCOMPLETE_HISTORY')
        if not valid(h.get('ttm_net_income_krw')):
            flags.append('NET_INCOME_MISSING')
        if not valid(h.get('cfo_ttm_krw')):
            flags.append('CFO_MISSING')
        if not valid(h.get('roe_ttm_pct_diagnostic')):
            flags.append('ROE_DIAGNOSTIC_MISSING')
        if valid(h.get('equity_end_krw')) and h['equity_end_krw'] <= 0:
            flags.append('NONPOSITIVE_EQUITY')
        formula = h.get('formula')
        if formula == 'FY_prior + current_YTD - previous_YTD':
            keys = ('prior_fy_net_income_krw','current_ytd_net_income_krw','previous_ytd_net_income_krw','ttm_net_income_krw')
            values = [h.get(k) for k in keys]
            if all(valid(v) for v in values):
                if values[0] + values[1] - values[2] != values[3]:
                    flags.append('TTM_ARITHMETIC_MISMATCH')
            else:
                flags.append('TTM_ARITHMETIC_UNVERIFIABLE')
        elif formula == 'FY_current':
            if h.get('ttm_net_income_krw') != h.get('current_ytd_net_income_krw'):
                flags.append('FY_ARITHMETIC_MISMATCH')
        else:
            flags.append('UNKNOWN_TTM_FORMULA')
        rows[code] = {'name': h.get('ISU_NM'), 'period': h.get('period'),
                      'history_status': h.get('status'), 'flags': sorted(flags),
                      'investment_grade': None, 'source_reconciled': False}
    counts = Counter(flag for r in rows.values() for flag in r['flags'])
    summary = {'companies': len(rows), 'complete': sum(r.get('history_status') == 'COMPLETE' for r in rows.values()),
               'partial': sum(r.get('history_status') == 'PARTIAL' for r in rows.values()),
               'flags': dict(sorted(counts.items())), 'investment_grades': 0,
               'source_reconciled': False, 'audit_scope': 'stored-data consistency only'}
    return summary, rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', required=True)
    p.add_argument('--output', default='stage13_history_audit')
    args = p.parse_args()
    summary, rows = audit(json.loads(Path(args.input).read_text(encoding='utf-8')))
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    (out/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'diagnostics.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
