"""Stage 15 read-only live history audit, change detection and triage."""
import argparse,json,math
from collections import Counter
from pathlib import Path
from v5_stage13_history_audit import audit

def diagnose(history, baseline=None):
    summary, rows=audit(history)
    baseline=baseline or {}
    old=baseline.get('diagnostics',baseline)
    if not isinstance(old,dict): old={}
    added=sorted(set(rows)-set(old)); removed=sorted(set(old)-set(rows))
    changed=[]; resolved=[]
    for code in sorted(set(rows)&set(old)):
        prev=set(old[code].get('flags',[])); now=set(rows[code].get('flags',[]))
        if prev!=now or old[code].get('period')!=rows[code].get('period'):
            changed.append({'code':code,'name':rows[code].get('name'),'added_flags':sorted(now-prev),'resolved_flags':sorted(prev-now),'previous_period':old[code].get('period'),'current_period':rows[code].get('period')})
            if prev-now: resolved.append(code)
    critical={'TTM_ARITHMETIC_MISMATCH','FY_ARITHMETIC_MISMATCH','NONPOSITIVE_EQUITY','INVALID_RECORD','STATEMENT_IDENTITY_MISSING'}
    missing={'CFO_MISSING','NET_INCOME_MISSING','INCOMPLETE_HISTORY','ROE_DIAGNOSTIC_MISSING','TTM_ARITHMETIC_UNVERIFIABLE','UNKNOWN_TTM_FORMULA'}
    triage=[]
    for code,row in rows.items():
        flags=set(row['flags']); category='CRITICAL' if flags&critical else 'MISSING_DATA' if flags&missing else 'STATEMENT_REVIEW' if 'SEPARATE_STATEMENT_REVIEW' in flags else 'NO_STORED_DATA_FLAGS'
        if category!='NO_STORED_DATA_FLAGS':triage.append({'code':code,'name':row.get('name'),'category':category,'flags':sorted(flags),'period':row.get('period')})
    priority={'CRITICAL':0,'MISSING_DATA':1,'STATEMENT_REVIEW':2}
    triage.sort(key=lambda r:(priority[r['category']],r['code']))
    summary['baseline_companies']=len(old);summary['new_codes']=len(added);summary['removed_codes']=len(removed);summary['changed_records']=len(changed);summary['triage_counts']=dict(Counter(x['category'] for x in triage));summary['snapshot_only']=True
    return summary,rows,{'added_codes':added,'removed_codes':removed,'changed':changed,'resolved_codes':resolved},triage

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--baseline',required=True);p.add_argument('--output',default='stage15_report');a=p.parse_args()
    history=json.loads(Path(a.input).read_text(encoding='utf8')); baseline=json.loads(Path(a.baseline).read_text(encoding='utf8'))
    s,r,d,t=diagnose(history,baseline);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    for name,obj in [('summary',s),('diagnostics',r),('changes',d),('triage',t)]: (out/(name+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(s,ensure_ascii=False))
if __name__=='__main__':main()
