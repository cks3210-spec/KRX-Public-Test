"""Read-only CFO and financial-health join. No investment-grade output."""
import argparse, json
from pathlib import Path
try:
    from .v5_stage10_reconcile import reconcile, finite
except ImportError:
    from v5_stage10_reconcile import reconcile, finite


def join(pilot, history):
    rows = reconcile(pilot, history)
    for code, row in rows.items():
        h = history.get(code) or {}
        f = row['financial']; d = row['diagnostic']; flags = set(d['flags'])
        ident = h.get('identity') or []
        # Period and CFS/OFS must match, and report identity must agree with period.
        valid_identity = (len(ident) >= 3 and ident[:3] == ['2026', '11012', f.get('statement_type')]
                          and row.get('period') == '2026_H1' and h.get('period') == '2026_H1')
        if not valid_identity:
            f['cfo_ttm'] = None
            f['cfo_provenance'] = 'REJECTED_REPORT_IDENTITY'
            d['cfo_to_owner_net_income_provisional'] = None
            flags.add('CFO_REPORT_IDENTITY_MISMATCH')
            flags.add('MISSING_CFO_TTM')
        elif finite(f.get('cfo_ttm')):
            flags.discard('MISSING_CFO_TTM')
        assets = f.get('assets_current'); liabilities = f.get('liabilities_current'); equity = f.get('equity_current')
        f['balance_sheet_difference_krw'] = assets-liabilities-equity if all(finite(x) for x in (assets,liabilities,equity)) else None
        d['debt_to_equity_pct_provisional'] = round(liabilities/equity*100,4) if finite(liabilities) and finite(equity) and equity>0 else None
        ni = f.get('owner_net_income_ttm')
        d['roa_owner_ttm_pct_provisional'] = round(ni/assets*100,4) if finite(ni) and finite(assets) and assets>0 else None
        if f['balance_sheet_difference_krw'] != 0: flags.add('BALANCE_SHEET_NOT_BALANCED')
        d['flags'] = sorted(flags)
        f['missing'] = sorted(set(x for x in f['missing'] if x != 'cfo_ttm') | ({'cfo_ttm'} if not finite(f.get('cfo_ttm')) else set()))
        row['source_reconciled'] = False; row['investment_grade'] = None
        f['source_reconciled'] = False; f['investment_grade'] = None
        d['investment_grade'] = None
    return rows


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',required=True);ap.add_argument('--history',required=True);ap.add_argument('--output',default='stage11_diagnostics');a=ap.parse_args()
    pilot=json.loads(Path(a.pilot).read_text(encoding='utf8'));hist=json.loads(Path(a.history).read_text(encoding='utf8'))
    rows=join(pilot,hist);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    summary={'companies':len(rows),'cfo_connected':sum(finite(x['financial']['cfo_ttm']) for x in rows.values()),'balanced':sum(x['financial']['balance_sheet_difference_krw']==0 for x in rows.values()),'investment_grades':0,'source_reconciled':False}
    (out/'diagnostics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
