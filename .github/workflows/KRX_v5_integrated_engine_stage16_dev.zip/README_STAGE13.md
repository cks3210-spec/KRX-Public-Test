# Stage 13 — read-only whole-history audit

Input: JSON object mapping stock code to records from `v5-state/v5_history/history_metrics.json`.

Run: `python v5/v5_stage13_history_audit.py --input history_metrics.json --output stage13_history_audit`

Outputs: `summary.json`, `diagnostics.json`. No trading grades, no repository writes.

IMPORTANT: This only checks stored record completeness and arithmetic; it is not an independent audit against OpenDART filings. To audit all companies locally, supply the full GitHub JSON file. Historical CFS total net income/total equity ROE must not be substituted for owner-attributable ROE.
