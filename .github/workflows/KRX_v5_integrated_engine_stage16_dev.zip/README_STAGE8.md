# KRX v5 Stage 8 — five-period growth diagnostics

- Added `v5/v5_growth_extension.py`: prior-year comparable TTM for revenue, operating income and parent-attributable net income.
- Five periods required: current YTD(Y), FY(Y-1), YTD(Y-1), FY(Y-2), YTD(Y-2).
- Formula: current TTM = FY(Y-1)+YTD(Y)-YTD(Y-1); prior TTM = FY(Y-2)+YTD(Y-1)-YTD(Y-2).
- Read-only, no production v4 or GC modification, no investment grades.
- Unit tests: `python -m unittest discover -s tests -q` (28 passed).
- Pending: actual OpenDART retrieval for the two additional periods, original filing reconciliation, non-calendar fiscal year and financial sector exceptions.
